# Hướng dẫn sử dụng phần mềm Office 365 và học trực tuyến; sử dụng hệ thống email do Trường cấp

> Nguồn: [Sổ tay sinh viên HUST](https://sv-ctt.hust.edu.vn/#/so-tay-sv)
> Ngày đăng trên nguồn: 2021-11-30 08:29:48
> Nhóm nội dung: Sổ tay SV

## Nội dung

Hiện tại các địa điểm trong khuôn viên giảng đường của Trường Đại học Bách khoa Hà Nội đã được phủ sóng wifi để phục vụ cho việc giảng dạy và học tập. Ngoài ra Nhà trường cũng đã mua bản quyền sử dụng phần mềm Microsoft Office 365 và cấp cho mỗi cán bộ và sinh viên của Trường 01 tài khoản sử dụng miễn phí.

Trong giai đoạn còn thực hiện giãn cách xã hội do ảnh hưởng của dịch Covid thì toàn bộ quá trình học tập trực tuyến sẽ dựa trên ứng dụng Microsoft Teams của bộ Office 365, do đó sinh viên cần chủ động cài đặt và sử dụng thành thạo phần mềm này.

Để có thể sử dụng hệ thống phần mềm Microsoft Office 365 và mạng wifi của Trường sinh viên cần đọc kỹ bộ tài liệu hướng dẫn đính kèm theo. Tài liệu hướng dẫn tập chung chủ yếu vào các nội dung sau:

### 1. Giới thiệu chung về Office 365 và hệ thống Wifi HUST

### 2. Hướng dẫn cài đặt Office 365 trên máy tính

### 3. Hướng dẫn quản lý tài khoản Office 365

3.1 Hướng dẫn tự đổi mật khẩu

3.2 Hướng dẫn đăng ký mới hoặc reset lại mật khẩu bị mất

3.3 Hướng dẫn thiết lập xác thực hai lớp để tăng cường bảo mật tài khoản

### 4. Hướng dẫn sử dụng nhanh hệ thống wifi HUST

### 5. Hướng dẫn sử dụng các ứng dụng Office 365 và hệ thống LMS

5.1 Hướng dẫn sử dụng MS Teams

5.2 Hướng dẫn sinh viên làm bài kiểm tra trên Microsoft Teams

5.3 Hướng dẫn sinh viên nộp bài tập trên Microsoft Teams

5.4 Giới thiệu các phần mềm khác của Office 365

5.5 Hướng dẫn sử dụng hệ thống học tập B-Learning (trên nền tảng LMS Moodle)

**Chi tiết hướng dẫn xemTẠI ĐÂY.** (https://husteduvn-my.sharepoint.com/:w:/g/personal/khai_tranquang_hust_edu_vn1/EZOoNe2pCgVJnWykRLAFwywB7qwqfyA285SRYIJU3yVVKA?e=rHr43u)

Sinh viên đặc biệt lưu ý **ĐỌC KỸ CÁC HƯỚNG DẪN TẠI MỤC 5** để có thể cài đặt và sử dụng phần mềm MS TEAMS **PHỤC VỤ CHO VIỆC HỌC TẬP TRỰC TUYẾN** trong thời gian còn thực hiện giãn cách xã hội.

6. Hướng dẫn sử dụng hệ thống email do Trường cấp

6.1 Đăng ký tạo mới, đổi mật khẩu online: **Xem tại đây** (https://bknic.hust.edu.vn/)

6.2 Sử dụng hệ thống email: **Xem tại đây** (https://bknic.hust.edu.vn/)

Trong quá trình thực hiện nếu có khó khăn vướng mắc xin liên hệ với:

**Trung tâm Mạng Thông tin**

- Văn phòng: Phòng 922 – Tòa nhà Thư viện Tạ Quang Bửu - Trường ĐHBK Hà Nội

- Số điện thoại hotline Office 365: 0243 868 2203

- Số điện thoại hotline LMS/ MS Teams: 0243 868 3188

- Số điện thoại hotline Wifi HUST: 0243 668 1426

- Trang web: https://bknic.hust.edu.vn (https://bknic.hust.edu.vn/)/

- Email: office-bknic@hust.edu.vn (mailto:office-bknic@hust.edu.vn)
