# Hướng dẫn quy trình thực hiện một số thủ tục thường gặp

> Nguồn: [Sổ tay sinh viên HUST](https://sv-ctt.hust.edu.vn/#/so-tay-sv)
> Ngày đăng trên nguồn: 2022-09-19 17:49:13
> Nhóm nội dung: Sổ tay SV

## Nội dung

1. Hướng dẫn đăng ký học tập: **Xem tại đây.** (https://ctt.hust.edu.vn/DisplayWeb/DisplayBaiViet?baiviet=6129)

2. Hướng dẫn đăng ký lớp cho sinh viên hệ đào tạo quốc tế SIE: **Xem tại đây.** (https://ctt.hust.edu.vn/DisplayWeb/DisplayBaiViet?baiviet=35630)

3. Hướng dẫn tra cứu điểm kỳ mới nhất để phục vụ công tác phúc tra: **Xem tại đây.** (https://ctt.hust.edu.vn/DisplayWeb/DisplayBaiViet?baiviet=34476)

4. Hướng dẫn thủ tục chuyển trường dành cho du học sinh và sinh viên quốc tế: **Xem tại đây.** (https://ctt.hust.edu.vn/DisplayWeb/DisplayBaiViet?baiviet=35798)

5. Hướng dẫn kiểm tra điều kiện tốt nghiệp: **Xem tại đây** (https://ctt.hust.edu.vn/DisplayWeb/DisplayBaiViet?baiviet=3179)

6. Hướng dẫn thủ tục xin nhận bằng hoặc xin giấy chứng nhận tốt nghiệp thay bằng bị mất: **Xem tại đây.** (https://ctt.hust.edu.vn/DisplayWeb/DisplayBaiViet?baiviet=35518)

7. Hướng dẫn thủ tục cấp bản sao bằng tốt nghiệp: **Xem tại đây.** (https://ctt.hust.edu.vn/DisplayWeb/DisplayBaiViet?baiviet=43)

8. Các hướng dẫn về: Giải quyết thủ tục hành chính sinh viên (giấy chứng nhận SV, giấy giới thiệu SV, giấy vay vốn ngân hàng, giấy làm thẻ xe buýt,...), mua Bảo hiểm, giải quyết chế độ chính sách miễn, giảm học phí...:**Xem tại đây. (https://sv-ctt.hust.edu.vn/#/so-tay-sv)**

### LIÊN HỆ

các thắc mắc sẽ gửi qua email theo hướng dẫn **TẠI ĐÂY** (https://sv-ctt.hust.edu.vn/#/so-tay-sv/69/huong-dan-gui-cau-hoi-toi-phong-dao-tao-cac-van-de-ve-hoc-tap-hoc-phi).

**(Các thủ tục khác sẽ tiếp tục được cập nhật)**
