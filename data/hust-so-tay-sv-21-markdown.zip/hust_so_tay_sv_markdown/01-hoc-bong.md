# Học bổng

> Nguồn: [Sổ tay sinh viên HUST](https://sv-ctt.hust.edu.vn/#/so-tay-sv)
> Ngày đăng trên nguồn: 2024-06-13 11:12:13
> Nhóm nội dung: Sổ tay SV

## Nội dung

Hiện tại có các nguồn học bổng như sau dành cho sinh viên:

### 1. Học bổng khuyến khích học tập (KKHT)

Năm học 2023-2024 ĐHBK Hà Nội dành khoảng 70 tỷ đồng cho quỹ học bổng KKHT để xét cấp cho sinh viên có kết quả học tập và rèn luyện tốt. Học bổng KKHT được xét theo học kỳ và có 3 mức:

- Học bổng loại khá (loại C): Tương đương với mức học phí sinh viên phải đóng

- Học bổng loại giỏi (loại B): Bằng 1,2 lần học bổng loại khá.

- Học bổng loại suất sắc (loại A): Bằng 1,5 lần học bổng loại khá.

Điều kiện được xét, cấp học bổng KKHT:

- Học bổng loại khá: Sinh viên có kết quả học tập và rèn luyện đạt từ loại khá trở lên.

- Học bổng loại giỏi: Sinh viên có kết quả học tập và rèn luyện đạt từ loại giỏi trở lên.

- Học bổng loại xuất sắc: Sinh viên có kết quả học tập và rèn luyện đạt từ loại xuất sắc trở lên.

Học bổng KKHT được xét cấp dựa trên kết quả học tập và rèn luyện của sinh viên (sinh viên không cần phải đăng ký).

Chi tiết Quy định về việc xét cấp học bổng KKHT (áp dụng từ năm học 2023-2024) sinh viên xem **TẠI ĐÂY.** (https://husteduvn-my.sharepoint.com/:b:/g/personal/khai_tranquang_hust_edu_vn1/ESU8utDOABpBvhl0inNyBEoBGqQ7ivEcjY8pYTvmBtoOJQ?e=ukfXKN)

### 2. Học bổng Trần Đại Nghĩa

Học bổng Trần Đại Nghĩa là Học bổng của ĐHBK Hà Nội xét cấp cho sinh viên có hoàn cảnh kinh tế gia đình đặc biệt khó khăn (hộ nghèo, hộ cận nghèo hoặc hộ có hoàn cảnh kinh tế đặc biệt khó khăn khác, sinh viên gặp tai nạn, rủi ro đột xuất) có kết quả học tập và rèn luyện tốt.

Học bổng Trần Đại Nghĩa xét theo học kỳ và có 2 mức tương ứng với 50% và 100% học phí.

**Kế hoạch, hồ sơ đăng ký xét cấp HB Trần Đại Nghĩa học kỳ 2 năm học 2023-2024 sinh viên xem **TẠI ĐÂY** (https://ctt.hust.edu.vn/DisplayWeb/DisplayBaiViet?baiviet=43409).**

Chi tiết Quy định về việc xét cấp Học bổng Trần Đại Nghĩa sinh viên xem **TẠI ĐÂY (https://husteduvn-my.sharepoint.com/:b:/g/personal/khai_tranquang_hust_edu_vn1/EaQb5XucFDpIjtckawafR2ABVFBqq5VQ4c-akklE2JjP3Q?e=ia25Rv).**

### 3. Học bổng tài trợ

Hàng năm sinh viên ĐHBK Hà Nội nhận được khoảng từ 5-7 tỷ đồng học bổng tài trợ từ các cá nhân, tổ chức, doanh nghiệp trong và ngoài nước như: học bổng Sumitomo, Toyota, Toshiba, Nitori, Samsung, LG, Lote, Posco, Merali, EVN, Petrolimex, CC Foundation, MB Bank, PTSC,...

- Chi tiết Quy định về việc xét cấp Học bổng tài trợ sinh viên xem **TẠI ĐÂY** (https://husteduvn-my.sharepoint.com/:b:/g/personal/khai_tranquang_hust_edu_vn1/EbEKhfFyCe9CvHP86a1I098BVsIOPCj_oUIwYXEZoZx5Vw?e=hUb8b0);

- Chi tiết về các chương trình học bổng tài trợ sinh viên xem **TẠI ĐÂY.** (https://sv-ctt.hust.edu.vn/#/hoc-bong)

### 4. Học bổng trao đổi sinh viên quốc tế

Với mục tiêu đẩy mạnh quốc tế hóa môi trường giáo dục, ĐHBK Hà Nội không chỉ tăng cường tiếp nhận giảng viên, sinh viên nước ngoài đến làm việc, học tập tại ĐHBK Hà Nội mà còn tích cực hỗ trợ mọi mặt để sinh viên ĐHBK Hà Nội có cơ hội đi học tập nâng cao trình độ chuyên môn, ngoại ngữ, phát triển kỹ năng tại các trường đối tác nước ngoài. Sinh viên có thể đăng ký tham gia các chương trình học bổng từ các nguồn sau:

#### a) Học bổng từ nguồn kinh phí của ĐHBK Hà Nội:

Từ năm 2024 ĐHBK Hà Nội bắt đầu triển khai chương trình cấp học bổng cho sinh viên sang học tập, thực tập ngắn hạn tại các trường đối tác nước ngoài. Kinh phí học bổng dành cho năm 2024 là 5 tỷ đồng. Chi tiết Quy định về việc xét cấp học bổng trao đổi sinh viên xem **TẠI ĐÂY** (https://husteduvn-my.sharepoint.com/:b:/g/personal/khai_tranquang_hust_edu_vn1/ESmC-Ftr_YVBnQw58JiYd0YBrD75bqrrbhBiyWqgXaPn8g?e=BnOJq3).

Chi tiết các chương trình học bổng trao đổi sinh viên sẽ được công bố trong mục Học bổng trên cổng thông tin đào tạo dành cho sinh viên (qldt.hust.edu.vn).

#### b) Học bổng từ các nguồn hợp tác quốc tế song phương và đa phương:

Ngoài nguồn học bổng do Đại học cấp, mỗi năm sinh viên ĐHBK Hà Nội còn nhận được hàng trăm suất học bổng tài trợ cho sinh viên sang học tập, thực tập tại nước ngoài từ các nguồn hợp tác quốc tế song phương và đa phương của ĐHBK Hà Nội. Chi tiết các chương trình học bổng tài trợ này sinh viên theo dõi **TẠI ĐÂY.** (https://www.hust.edu.vn/vi/su-kien-noi-bat/hop-tac-doi-ngoai-truyen-thong/)

### 5.Học bổng gắn kết quê hương

Nhằm gắn kết quá trình đào tạo, NCKH với hoạt động kinh doanh, sản xuất, năm 2024 ĐHBK Hà Nội sẽ dành 3 tỷ đồng để cấp Học bổng gắn kết quê hương cho sinh viên, học viên chương trình kỹ sư chuyên sâu đặc thù có đồ án/khóa luận tốt nghiệp (ĐANT) góp phần cải tiến, nâng cao chất lượng, hiệu quả kinh doanh, sản xuất hoặc chất lượng các dịch vụ an sinh xã hội tại quê hương của sinh viên/học viên.

Mức học bổng: Học bổng có trị giá 5 triệu đồng/ĐATN.

Sinh viên bảo vệ đồ án/khóa luận tốt nghiệp học kỳ 2 năm học 2023-2024 đủ điều kiện theo quy định đăng ký xét cấp học bổng gắn kết quê hương trên hệ thống qldt.hust.edu.vn đến hết ngày 30/6/2024 và hoàn thành việc nộp hồ sơ văn bản giấy tại bàn số 2 phòng 103 nhà C1 đến hết Thứ Sáu ngày 19/7/2024.

Chi tiết Quy định Học bổng Gắn kết quê hương xem **TẠI ĐÂY** (https://husteduvn-my.sharepoint.com/:b:/g/personal/khai_tranquang_hust_edu_vn1/ERg4NeFLkeBOu8j8SXfOHUoBBarqEtWAJHqETEODPYt5DA?e=wfLtCi).
