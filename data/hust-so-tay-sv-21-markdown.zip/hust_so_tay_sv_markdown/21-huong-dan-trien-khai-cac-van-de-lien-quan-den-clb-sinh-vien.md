# Hướng dẫn triển khai các vấn đề liên quan đến CLB Sinh viên

> Nguồn: [Sổ tay sinh viên HUST](https://sv-ctt.hust.edu.vn/#/so-tay-sv)
> Ngày đăng trên nguồn: 2023-12-29 13:53:17
> Nhóm nội dung: Sổ tay SV

## Nội dung

Nhằm thúc đẩy hoạt động các CLB sinh viên và đảm bảo mục tiêu:

- Tạo môi trường hoạt động đa dạng phong phú, phù hợp với nhu cầu lợi ích thiết thực để sinh viên có khả năng và năng khiếu được bộc lộ, phát triển; Tạo điều kiện cho sinh viên rèn luyện trưởng thành về mọi mặt; Nâng cao nhận thức về bản lĩnh chính trị, đạo đức, lối sống, giáo dục lý tưởng cách mạng, truyền thống của dân tộc, quy tắc ứng xử văn minh cho sinh viên, góp phần đổi mới, nâng cao chất lượng giáo dục và đào tạo.

- Khuyến khích nhiều sinh viên tham gia hoạt động của CLB sinh viên do các đơn vị trong Trường quản lý; Thu hút nhiều sự hỗ trợ nguồn lực từ các cá nhân và tổ chức trong và ngoài trường nhằm thúc đẩy sự phát triển bền vững của CLB sinh viên; Đảm bảo sử dụng hiệu quả các đầu tư của Nhà trường cho CLB sinh viên.

- Tăng cường công tác hỗ trợ giải quyết các khó khăn, vướng mắc trong triển khai các hoạt động của CLB sinh viên; Tạo sự thống nhất trong công tác hỗ trợ và quản lý giữa các đơn vị trong trường, đảm bảo thường xuyên định hướng và nắm bắt đầy đủ tình hình hoạt động của CLB sinh viên theo định hướng đào tạo của Nhà trường.

Đại học BKHN đã:

- Ban hành chính sách quản lý và hỗ trợ các CLB SV (chi tiết xem tại đây (https://drive.google.com/file/d/1XjlCGBOtz1Vr9-pSbLPYDDdbE9kT0j-U/view?usp=sharing)). Văn bản chứa các thông tin liên quan đến Quy trình thành lập, trách nhiệm và quyền lợi của việc tham gia CLB SV,...

- Ban hành kế hoạch hỗ trợ phát triển CLB SV (chi tiết xem tại đây (https://ctsv.hust.edu.vn/#/ke-hoach)). Văn bản chứa các thông tin liên quan đến các hoạt động chính của CLB trong năm học, vai trò trách nhiệm của các đơn vị liên quan.

- Lập danh sách các CLB SV (chi tiết xem tại đây (https://hust.edu.vn/vi/sinh-vien/hoat-dong-cua-sinh-vien/cau-lac-bo-sinh-vien-654597.html)). Bài viết giới thiệu danh sách các CLB SV đã đăng ký hoạt động với nhà trường.

- Triển khai kênh tiếp nhận các yêu cầu của CLB như:

- Mượn phòng sinh hoạt CLB tại đây: https://ctsv.hust.edu.vn/#/viet-giay/22_don_dang_ky_muon_phong (https://ctsv.hust.edu.vn/#/viet-giay/22_don_dang_ky_muon_phong)

- Đăng ký đặt bàn truyền thông hoạt động của CLB: https://ctsv.hust.edu.vn/#/viet-giay/23_don_dang_ky_dat_ban (https://ctsv.hust.edu.vn/#/viet-giay/23_don_dang_ky_dat_ban)

Nếu cần tư vấn thêm các bạn có thể đến phòng 102 - C1, Ban Công tác sinh viên gặp Phó trưởng Ban phụ trách để được hỗ trợ.
