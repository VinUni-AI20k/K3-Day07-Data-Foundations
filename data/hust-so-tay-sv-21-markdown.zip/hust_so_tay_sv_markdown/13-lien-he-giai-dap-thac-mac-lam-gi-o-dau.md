# Liên hệ, giải đáp thắc mắc (làm gì? ở đâu?)

> Nguồn: [Sổ tay sinh viên HUST](https://sv-ctt.hust.edu.vn/#/so-tay-sv)
> Ngày đăng trên nguồn: 2023-10-12 13:38:30
> Nhóm nội dung: Sổ tay SV

## Nội dung

### I. Phòng Đào tạo

#### 1. Thông tin liên hệ:

- Địa chỉ: Phòng 201 – 202 – 203 – 204 -204 nhà C1

- Điện thoại: 024.3869.2008

- Email: dt@hust.edu.vn (mailto:dt@hust.edu.vn)

- Fanpage: facebook.com/DTDHBKHN (http://www.facebook.com/DTDHBKHN)

#### 2. Các thủ tục giải quyết tại Phòng Đào tạo:

- Đăng ký học tập, rút/ hủy học phần, thời khóa biểu, lịch thi, hoãn thi, thi bù.

- Xử lý học tập: Điểm học phần, học phần tương đương, thay thế GPA, CPA, cảnh báo học tập, chương trình đào tạo.

- Chuyển ngành, chuyển hệ đào tạo, chuyển trường, thôi học, nghỉ học, quay lại học tập.

- Tốt nghiệp (nhận ĐA/KL tốt nghiệp; văn bằng, thứ hạng tốt nghiệp, thanh toán ra Trường).

- Học phí: Tính học phí, tính tiền miễn giảm học phí, thu học phí.

- Giải đáp các thắc mắc liên quan đến điều kiện về điểm, trình độ năm học, trình độ ngoại ngữ để xét cấp các loại học bổng.

- Cấp bảng trích sao kết quả học tập (bảng điểm).

- Reset mật khẩu tài khoản tài khoản trang ctt-sis.hust.edu.vn.

Chi tiết hướng dẫn liên hệ giải quyết các thủ tục hành chính và giải đáp các thắc mắc với Phòng Đào tạo sinh viên xem **TẠI ĐÂY.** (https://sv-ctt.hust.edu.vn/#/so-tay-sv/69/huong-dan-gui-cau-hoi-toi-phong-dao-tao-cac-van-de-ve-hoc-tap-hoc-phi)

### II. Phòng Công tác Sinh viên

#### 1. Thông tin liên hệ:

- Địa chỉ: Phòng 101 – 102 – 103 – 104 -104 nhà C1

- Điện thoại: 024.3869.2896 (Phòng 102 nhà C1); 024.3869.3108 (Phòng 103-104 nhà C1)

- Email: ctsv@hust.edu.vn (mailto:ctsv@hust.edu.vn)

- Fanpage: https://www.facebook.com/ctsv.hust.edu.vn (https://www.facebook.com/ctsv.hust.edu.vn)

#### 2. Các thủ tục giải quyết tại Phòng Công tác Sinh viên:

- Cấp các loại giấy tờ hành chính sinh viên: Giấy chứng nhận sinh viên, giấy giới thiệu sinh viên, giấy vay vốn ngân hàng, giấy ưu đãi trong giáo dục, giấy làm vé xe buýt tháng,…

- Học bổng: Học bổng khuyến khích học tập, học bổng Trần Đại Nghĩa, học bổng tài trợ (hồ sơ, quy trình thủ tục xét cấp học bổng; điều kiện xét cấp học bổng; chi trả học bổng,…).

- Giải quyết chế độ chính sách miễn, giảm học phí, hỗ trợ chi phí học tập: Tư vấn, tiếp nhận và xét duyệt hồ sơ miễn, giảm học phí; hỗ trợ chi phí học tập.

- Công tác bảo hiểm y tế: Hỗ trợ sinh viên mua bảo hiểm, sử dụng BHYT trong khám chữa bệnh.

- Hỗ trợ sinh viên nước ngoài (về thủ tục hành chính, cấp mới và gia hạn thị thực nhập cảnh, đời sống sinh viên).

- Hỗ trợ sinh viên khó khăn: Tư vấn và hỗ trợ sinh viên gặp khó khăn trong học tập, khó khăn về tài chính, đời sống tâm lý.

- Tổ chức các hoạt động ngoại khóa cho sinh viên: Tuần sinh hoạt công dân sinh viên năm đầu và năm cuối; các sự kiện sinh hoạt ngoại khóa khác của Trường.

- Tiếp nhận đăng ký tổ chức các hoạt động ngoại khóa cho sinh viên trong khuôn viên Trường.

- Tiếp nhận và hỗ trợ sinh viên làm thủ tục thành lập câu lạc bộ sinh viên.

- Chỉnh sửa thông tin sinh viên trên trang cổng thông tin sinh viên ctt.hust.edu.vn.

- Cấp mới và cấp lại thẻ sinh viên; cấp giấy chứng nhận sinh viên tạm thời thay thế cho thẻ sinh viên.

Mọi thắc mắc liên quan đến công việc do Phòng Công tác Sinh phụ trách viên sinh viên có thể đặt câu hỏi **TẠI ĐÂY.** (https://ctsv.hust.edu.vn/#/viet-giay/1)

### III. Các viện đào tạo

- Tư vấn hỗ trợ sinh viên về chương trình đào tạo; đăng ký học tập; định hướng nghề nghiệp.

- Cấp bảng trích sao kết quả học tập, giấy chứng nhận sinh viên, giấy giới thiệu sinh viên, giấy làm vé xe buýt tháng.

- Tư vấn hỗ trợ về việc thực hiện chế độ chính sách, học bổng, việc làm cho sinh viên.
