# Hướng dẫn chụp, công chứng và rút học bạ trong hồ sơ sinh viên

> Nguồn: [Sổ tay sinh viên HUST](https://sv-ctt.hust.edu.vn/#/so-tay-sv)
> Ngày đăng trên nguồn: 2023-07-05 15:57:45
> Nhóm nội dung: Sổ tay SV

## Nội dung

Theo yêu cầu quản lý hồ sơ sinh viên của Đại học, sinh viên phải nộp hồ sơ sinh viên bao gồm các giấy tờ và Học bạ cấp 3 bản chính. Trong quá trình học tập, hồ sơ sinh viên được quản lý bởi Phòng CTSV.

Nếu sinh viên có yêu cầu gồm:

### 1. Chụp ảnh học bạ

- Các bạn có thể vào mục Hồ sơ sinh viên để tải bản mềm ảnh chụp học bạ do các bạn đã tải lên hệ thống khi khai hồ sơ nhập học trực tuyến tại đây: https://ctsv.hust.edu.vn/#/cap-nhat-ho-so (https://ctsv.hust.edu.vn/#/cap-nhat-ho-so), đăng nhập bằng tài khoản email trường cấp.

- Nếu chưa tải lên, hoặc ảnh không đảm bảo chất lượng bạn đăng ký chụp lại tại đây: https://ctsv.hust.edu.vn/#/viet-giay/30_HOSO (https://ctsv.hust.edu.vn/#/viet-giay/30_HOSO)

### 2. Sao y công chứng học bạ

Để nhận bản sao y công chứng học bạ các bạn thực hiện các bước dưới đây:

- B1: Bạn đăng ký công chứng tại đây: https://ctsv.hust.edu.vn/#/viet-giay/30_HOSO (https://ctsv.hust.edu.vn/#/viet-giay/30_HOSO), đăng nhập bằng tài khoản email trường cấp.

- B2: Lên phòng 102-c1, vào bàn 3 gặp thầy Thụy để làm thủ tục nhận bản công chứng học bạ.

Lưu ý: Bản sao y học bạ chỉ cung cấp cho chính sinh viên yêu cầu. Do đó, khi đi làm thủ tục công chứng học bạ sinh viên mang theo thẻ sinh viên và căn cước công dân. Trong trường hợp sinh viên không tự đến được, phụ huynh lấy hộ phải có giấy ủy quyền của sinh viên, bản sao công chứng căn cước công dân của sinh viên và phụ huynh.

### 3. Rút học bạ (hồ sơ sinh viên)

Sinh viên chỉ rút học bạ gốc trong các trường hợp có: (1) Quyết định thôi học hoặc (2) Quyết định nghỉ học, bảo lưu học tập do Ban Giám đốc ĐHBK HN ký. Để nhận lại học bạ bản gốc sinh viên thực hiện các bước sau:

- B1: Cầm quyết định thôi học hoặc quyết định nghỉ học bảo lưu học tập đến phòng 102 - c1 vào bàn 3 để được hướng dẫn

- B2: Thực hiện thủ tục thanh toán ra trường, xác nhận không còn công nợ.

- B3: Chờ, đến nhận lại học bạ bản gốc theo lịch hẹn.

Bản chính học bạ chỉ trả cho chính sinh viên yêu cầu. Do đó, khi đi làm thủ tục công chứng học bạ sinh viên cầm theo thẻ căn cước công dân. Trong trường hợp sinh viên không tự đến được, phụ huynh phải có giấy ủy quyền của sinh viên, bản sao công chứng căn cước công dân của sinh viên và phụ huynh.

Nếu muốn được hướng dẫn thêm, Sinh viên đến phòng 102 - C1, gặp cán bộ Phòng CTSV để được hướng dẫn chi tiết.
